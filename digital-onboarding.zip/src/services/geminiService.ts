import { GoogleGenAI, Type } from "@google/genai";
import { ChatMessage, VendorProfile } from "../types";

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const getGeminiResponse = async (history: ChatMessage[], message: string, language: string = 'en') => {
  const response = await genAI.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] })),
      { role: "user", parts: [{ text: message }] }
    ],
    config: {
      systemInstruction: `You are Digital Onboarding Assistant, a dynamic and professional expert for small-scale vendors in India. 
      Your goal is to provide real-time, perpetually updated guidance for Kirana store owners, home bakers, and local sellers on regulatory compliance (FSSAI, GST, MSME) and digital platform onboarding (Swiggy, Zomato, Amazon, ONDC). 
      You stay synchronized with current regulations and predictively guide vendors through upcoming policy shifts (2024, 2025, 2026, 2027, and beyond). 
      Provide clear, step-by-step guidance in a helpful and professional tone. 
      Keep responses concise and practical. Use bullet points for clarity.
      IMPORTANT: Respond in the user's preferred language: ${language}.`,
    }
  });

  return response.text || "I'm sorry, I couldn't process that request.";
};

export const generateRoadmapSteps = async (vendorProfile: VendorProfile, language: string = 'en') => {
  const currentYear = new Date().getFullYear();
  const platforms = vendorProfile.platforms || [];
  const licenses = [
    vendorProfile.hasFSSAI ? 'FSSAI' : '',
    vendorProfile.hasGST ? 'GST' : '',
    vendorProfile.hasMSME ? 'MSME' : ''
  ].filter(Boolean);

  const prompt = `Act as a real-time regulatory compliance engine for Indian small businesses. 
  Generate a comprehensive, step-by-step digital roadmap for the following profile:
  - Business: ${vendorProfile.businessName} (Type: ${vendorProfile.businessType})
  - Location: ${vendorProfile.location}
  - Platforms of Interest: ${platforms.join(', ')}
  - Current Licenses: ${licenses.length > 0 ? licenses.join(', ') : 'None'}

  STRATEGIC INSTRUCTIONS:
  1. PLATFORM ONBOARDING: For each requested platform (${platforms.join(', ')}), provide a dedicated category with 5-7 ultra-specific steps for onboarding. Include Swiggy, Zomato, Amazon, and ONDC. 
  2. LICENSE UTILIZATION: For each license (FSSAI, GST, MSME), provide a dedicated category outlining the latest registration process. IMPORTANT: Within these steps, explicitly explain HOW and WHERE to use these license numbers during platform onboarding (e.g., "Enter your GSTIN in the 'Tax Details' section of the Amazon Seller portal").
  3. DIGITAL STEPS: Include categories for Digital Payments setup, Digital Hygiene Rating, and Food Safety Audits (HRA) if relevant.
  4. NO ENGLISH FALLBACK: Every single field in the returned JSON MUST be translated into ${language}. This includes step titles, descriptions, sub-steps, and document names. DO NOT leave technical terms in English if there is a common local language equivalent.
  5. RECENT POLICIES: Ensure steps reflect ${currentYear} policies and are future-proofed for next year.

  Return the response as a JSON array of objects with:
  - 'title': short name of the step (MUST BE TRANSLATED)
  - 'description': one-line summary (MUST BE TRANSLATED)
  - 'category': one of: compliance, platform, digital
  - 'detailedSteps': array of 5-7 specific sub-steps (latest procedures, MUST BE TRANSLATED)
  - 'requiredDocs': array of documents needed (MUST BE TRANSLATED)
  - 'officialLink': URL to the official registration portal
  - 'isRequired': boolean
  - 'lastVerified': a string in format "Live: [Month] [Year]" (e.g. "Live: May 2024")

  Respond ENTIRELY in the following language: ${language}.`;

  const response = await genAI.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            category: { type: Type.STRING, enum: ["compliance", "platform", "digital"] },
            detailedSteps: { type: Type.ARRAY, items: { type: Type.STRING } },
            requiredDocs: { type: Type.ARRAY, items: { type: Type.STRING } },
            officialLink: { type: Type.STRING },
            isRequired: { type: Type.BOOLEAN },
            lastVerified: { type: Type.STRING }
          },
          required: ["title", "description", "category", "detailedSteps", "requiredDocs", "officialLink", "isRequired", "lastVerified"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    console.error("Failed to parse roadmap steps", e);
    return [];
  }
};
