import { motion } from 'motion/react';
import { Info, Users, Lightbulb, CheckCircle2, ShoppingBag, Globe, Store, Truck } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function AboutSection() {
  const { t } = useLanguage();

  const platforms = [
    {
      id: 'fssai',
      name: t('fssaiLicense'),
      desc: t('fssaiLicenseDesc') || 'Mandatory legal authorization for food manufacturing and sales in India.',
      icon: <CheckCircle2 className="w-6 h-6 text-emerald-500" />,
      color: 'bg-emerald-50',
      steps: [
        'Access the FoSCoS portal and select "Registration" for Small Business/Petty Retailer.',
        'Upload the mandatory FSMS declaration and business address proof.',
        'Provide identity proof and a professional photograph.',
        'Pay the prescribed annual fee for a 1 to 5-year duration.',
        'Undergo a physical or digital inspection if mandated by the officer.',
        'Download the digitally signed certificate once the application status is approved.',
        'Display the FSSAI logo and registration number on your premises.'
      ]
    },
    {
      id: 'swiggy',
      name: t('swiggyZomato'),
      desc: t('swiggyZomatoDesc'),
      icon: <Truck className="w-6 h-6 text-orange-500" />,
      color: 'bg-orange-50',
      steps: t('swiggySteps') as string[]
    },
    {
      id: 'amazon',
      name: t('amazonFlipkart'),
      desc: t('amazonFlipkartDesc'),
      icon: <ShoppingBag className="w-6 h-6 text-blue-500" />,
      color: 'bg-blue-50',
      steps: t('amazonSteps') as string[]
    },
    {
      id: 'ondc',
      name: t('ondcNetwork'),
      desc: t('ondcNetworkDesc'),
      icon: <Globe className="w-6 h-6 text-emerald-500" />,
      color: 'bg-emerald-50',
      steps: t('ondcSteps') as string[]
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-24"
        >
          <motion.div
            variants={itemVariants}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-700 text-sm font-medium mb-6"
          >
            <Info className="w-4 h-4" />
            {t('learnMore')}
          </motion.div>
          <motion.h2 
            variants={itemVariants}
            className="text-4xl md:text-5xl font-black text-stone-900 mb-6 tracking-tight"
          >
            {t('aboutTitle')}
          </motion.h2>
          <motion.p 
            variants={itemVariants}
            className="text-xl text-stone-600 max-w-3xl mx-auto leading-relaxed"
          >
            {t('aboutText')}
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-32">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="inline-flex p-4 rounded-3xl bg-emerald-600 shadow-lg shadow-emerald-100">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-3xl font-black text-stone-900 leading-tight">
              {t('vendorFocusTitle')}
            </h3>
            <p className="text-lg text-stone-600 leading-relaxed">
              {t('vendorFocusText')}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                t('kiranaStores'),
                t('homeBakers'),
                t('localBoutiques'),
                t('artisansCraftsmen'),
                t('smallFoodOutlets'),
                t('localServices')
              ].map((item, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ x: 5 }}
                  className="flex items-center gap-3 p-4 bg-stone-50 rounded-2xl border border-stone-100"
                >
                  <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  </div>
                  <span className="text-sm font-bold text-stone-700">{item}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.95, rotate: -2 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative z-10 rounded-[3rem] overflow-hidden shadow-2xl border-[12px] border-white">
              <img
                src="https://picsum.photos/seed/vendor/1000/800"
                alt="Small scale vendor"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -top-6 -right-6 w-32 h-32 bg-emerald-600 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob" />
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-blue-600 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000" />
          </motion.div>
        </div>

        <div className="bg-stone-900 rounded-[4rem] p-8 md:p-20 relative overflow-hidden">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="w-16 h-16 rounded-3xl bg-emerald-500 flex items-center justify-center mb-8 shadow-lg shadow-emerald-500/20">
                <Lightbulb className="w-8 h-8 text-stone-900" />
              </div>
              <h3 className="text-4xl font-black text-white mb-6">
                {t('howItWorksTitle')}
              </h3>
              <p className="text-stone-400 text-lg leading-relaxed">
                {t('aiEngineDesc')}
              </p>
            </div>
            <div className="grid gap-6">
              {[
                { step: '01', text: t('howItWorksStep1') },
                { step: '02', text: t('howItWorksStep2') },
                { step: '03', text: t('howItWorksStep3') }
              ].map((item, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ x: 10 }}
                  className="flex items-center gap-6 p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl"
                >
                  <span className="text-4xl font-black text-emerald-500/30">
                    {item.step}
                  </span>
                  <p className="text-lg text-white font-bold leading-tight">
                    {item.text}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-600 rounded-full blur-[120px] opacity-20" />
        </div>

        {/* Marketplace Platforms Section */}
        <div className="mt-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-sm font-medium mb-6">
              <ShoppingBag className="w-4 h-4" />
              {t('categoryPlatform')}
            </div>
            <h3 className="text-4xl font-black text-stone-900 mb-6">
              {t('marketplaceTitle')}
            </h3>
            <p className="text-xl text-stone-600 max-w-2xl mx-auto">
              {t('marketplaceSubtitle')}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 gap-12">
            {platforms.map((platform, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`${platform.color} p-12 rounded-[3.5rem] border border-white/50 backdrop-blur-sm shadow-xl shadow-stone-100 transition-all`}
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-12 mb-12">
                  <div className="max-w-xl">
                    <div className="bg-white p-5 rounded-3xl w-fit shadow-md mb-8">
                      {platform.icon}
                    </div>
                    <h4 className="text-4xl font-black text-stone-900 mb-4">{platform.name}</h4>
                    <p className="text-xl text-stone-600 leading-relaxed font-medium">
                      {platform.desc}
                    </p>
                  </div>
                  <div className="px-6 py-2 rounded-full bg-white/50 border border-white text-xs font-black uppercase tracking-widest text-stone-400">
                    {platform.steps.length} {t('stepsDone').split(' ')[1]}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {platform.steps.map((stepText, idx) => (
                    <motion.div 
                      key={idx}
                      whileHover={{ scale: 1.02 }}
                      className="p-6 bg-white/70 backdrop-blur-sm rounded-2xl border border-white/50 flex items-start gap-5 shadow-sm"
                    >
                      <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-sm font-black shadow-md shrink-0 text-stone-900 border border-stone-100">
                        {idx + 1}
                      </div>
                      <p className="text-base font-bold text-stone-700 leading-relaxed">
                        {stepText}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          {/* CTA at the end of Marketplace section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-20 text-center"
          >
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="group relative inline-flex items-center gap-3 px-12 py-5 bg-stone-900 text-white rounded-full font-black text-lg transition-all hover:scale-105 active:scale-95 shadow-xl shadow-stone-200"
            >
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-orange-500/20 to-blue-500/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              {t('getStarted')}
              <Truck className="w-6 h-6 transition-transform group-hover:translate-x-1" />
            </button>
            <p className="mt-6 text-stone-400 text-sm font-bold uppercase tracking-widest">
              {t('marketplaceSubtitle')}
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
