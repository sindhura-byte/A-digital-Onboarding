import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { VendorProfile, OnboardingRoadmap, RoadmapStep } from '../types';
import { db } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { CheckCircle2, Circle, Clock, Layout, Shield, Globe, ExternalLink, FileText, Share2, ChevronDown, RefreshCw, Zap } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { generateRoadmapSteps } from '../services/geminiService';
import Guides from './Guides';

interface RoadmapProps {
  vendor: VendorProfile;
  roadmap: OnboardingRoadmap | null;
}

export default function Roadmap({ vendor, roadmap }: RoadmapProps) {
  const { t } = useLanguage();
  const [expandedStep, setExpandedStep] = useState<number | null>(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const toggleStep = async (index: number) => {
    if (!roadmap) return;
    const newSteps = [...roadmap.steps];
    newSteps[index].status = newSteps[index].status === 'completed' ? 'pending' : 'completed';
    
    try {
      await updateDoc(doc(db, 'roadmaps', vendor.userId), {
        steps: newSteps
      });
    } catch (error) {
      console.error("Error updating step", error);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    const lang = t('languageCode') || 'en';
    try {
      const newSteps = await generateRoadmapSteps(vendor, lang);
      await updateDoc(doc(db, 'roadmaps', vendor.userId), {
        steps: newSteps,
        language: lang,
        updatedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error refreshing roadmap", error);
    } finally {
      setIsRefreshing(false);
    }
  };

  const getCategoryIcon = (category: RoadmapStep['category']) => {
    switch (category) {
      case 'compliance': return <Shield className="w-5 h-5" />;
      case 'platform': return <Layout className="w-5 h-5" />;
      case 'digital': return <Globe className="w-5 h-5" />;
    }
  };

  const completedCount = roadmap?.steps.filter(s => s.status === 'completed').length || 0;
  const totalCount = roadmap?.steps.length || 0;
  const progress = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sidebar Info */}
        <div className="lg:col-span-1 space-y-6">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white p-6 rounded-[2rem] shadow-sm border border-stone-100"
          >
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center">
                <Zap className="w-4 h-4 text-emerald-600" />
              </div>
              <h3 className="text-lg font-bold text-stone-900">{t('welcome')}</h3>
            </div>
            
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-1">{t('businessNameLabel')}</p>
                <p className="text-stone-900 font-bold">{vendor.businessName}</p>
              </div>
              <div>
                <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-1">{t('businessType')}</p>
                <p className="text-stone-900 font-bold capitalize">{t(`businessType${vendor.businessType.charAt(0).toUpperCase() + vendor.businessType.slice(1)}`)}</p>
              </div>
              <div>
                <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-1">{t('location')}</p>
                <p className="text-stone-900 font-bold">{vendor.location}</p>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-stone-50">
              <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-600 uppercase tracking-widest mb-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                {t('liveTracking')}
              </div>
              <p className="text-xs text-stone-500 leading-relaxed font-medium">
                {t('engineDesc')}
              </p>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-emerald-600 p-8 rounded-[2rem] text-white shadow-xl shadow-emerald-100 relative overflow-hidden"
          >
            <div className="relative z-10">
              <h3 className="text-lg font-bold mb-2">{t('finished')}</h3>
              <div className="flex items-end gap-2 mb-4">
                <span className="text-4xl font-black">{Math.round(progress)}%</span>
                <span className="text-emerald-100 text-sm pb-1">{t('finished')}</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full overflow-hidden mb-2">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ type: "spring", stiffness: 50 }}
                  className="h-full bg-white"
                />
              </div>
              <p className="text-emerald-100 text-[10px] font-bold uppercase tracking-widest">
                {completedCount} / {totalCount} {t('stepsDone')}
              </p>
            </div>
            <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-32 h-32 bg-emerald-500 rounded-full blur-2xl opacity-50" />
          </motion.div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="w-full py-4 px-6 bg-white border-2 border-stone-100 text-stone-900 rounded-2xl font-bold flex items-center justify-center gap-3 hover:border-emerald-200 hover:bg-emerald-50 transition-all shadow-sm disabled:opacity-50"
          >
            <RefreshCw className={`w-5 h-5 text-emerald-600 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? t('refreshing') : t('refreshRoadmap')}
          </motion.button>
        </div>

        {/* Main Roadmap */}
        <div className="lg:col-span-2 space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-3xl font-black text-stone-900">{t('roadmapTitle')}</h2>
              <div className="flex items-center gap-2 text-stone-500 mt-1">
                <Clock className="w-4 h-4" />
                <span className="text-sm font-medium">{t('roadmapSubtitle')}</span>
              </div>
            </div>
            {roadmap?.updatedAt && (
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-stone-100 rounded-full text-[10px] font-bold text-stone-600 uppercase tracking-wider">
                {t('lastVerified')}: {new Date(roadmap.updatedAt).toLocaleDateString()}
              </div>
            )}
          </div>

          <div className="space-y-4">
            <AnimatePresence mode="popLayout">
              {roadmap?.language && roadmap.language !== t('languageCode') && (
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-6 p-4 bg-orange-50 border-2 border-orange-100 rounded-2xl flex items-center justify-between gap-4"
                >
                  <p className="text-sm font-bold text-orange-800">
                    {t('roadmapIn')} {roadmap.language.toUpperCase()}. {t('seeItIn')} {t('languageCode').toUpperCase()}?
                  </p>
                  <button
                    onClick={handleRefresh}
                    className="px-4 py-2 bg-orange-600 text-white rounded-lg text-xs font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-md shadow-orange-200"
                  >
                    {t('refreshSteps')}
                  </button>
                </motion.div>
              )}

              {roadmap?.steps.map((step, index) => (
                <motion.div
                  layout
                  key={step.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.05 }}
                  className={`group overflow-hidden rounded-[2rem] border-2 transition-all ${
                    step.status === 'completed' 
                      ? 'bg-emerald-50/50 border-emerald-100' 
                      : 'bg-white border-stone-100 shadow-sm hover:shadow-md hover:border-stone-200'
                  }`}
                >
                  <div 
                    className="p-6 cursor-pointer" 
                    onClick={() => setExpandedStep(expandedStep === index ? null : index)}
                  >
                    <div className="flex gap-4">
                      <motion.div 
                        whileTap={{ scale: 0.8 }}
                        onClick={(e) => { e.stopPropagation(); toggleStep(index); }}
                        className={`mt-1 flex-shrink-0 cursor-pointer h-8 w-8 rounded-full flex items-center justify-center transition-colors ${
                          step.status === 'completed' ? 'bg-emerald-600 text-white' : 'bg-stone-50 text-stone-300 border border-stone-200'
                        }`}
                      >
                        {step.status === 'completed' ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5 text-stone-200 fill-stone-50" />}
                      </motion.div>
                      
                      <div className="flex-grow">
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest ${
                            step.category === 'compliance' ? 'bg-blue-100 text-blue-700' :
                            step.category === 'platform' ? 'bg-purple-100 text-purple-700' :
                            'bg-orange-100 text-orange-700'
                          }`}>
                            {t(`category${step.category.charAt(0).toUpperCase() + step.category.slice(1)}`)}
                          </span>
                          {step.isRequired && (
                            <span className="px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest bg-red-100 text-red-700">
                              {t('mandatory')}
                            </span>
                          )}
                          {step.lastVerified && (
                            <span className="px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest bg-emerald-100 text-emerald-700">
                              {step.lastVerified}
                            </span>
                          )}
                        </div>
                        
                        <h4 className={`text-xl font-black ${step.status === 'completed' ? 'text-emerald-900 line-through opacity-50' : 'text-stone-900'}`}>
                          {step.title}
                        </h4>
                        <p className={`mt-1.5 text-sm leading-relaxed ${step.status === 'completed' ? 'text-emerald-700 opacity-50' : 'text-stone-500'}`}>
                          {step.description}
                        </p>
                      </div>

                      <motion.div
                        animate={{ rotate: expandedStep === index ? 180 : 0 }}
                        className="text-stone-300 group-hover:text-stone-400"
                      >
                        <ChevronDown className="w-6 h-6" />
                      </motion.div>
                    </div>

                    <AnimatePresence>
                      {expandedStep === index && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <div className="mt-8 pt-8 border-t border-stone-100 space-y-8">
                            {step.detailedSteps && step.detailedSteps.length > 0 && (
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {step.detailedSteps.map((s, i) => (
                                  <div key={i} className="flex gap-3 p-3 bg-stone-50 rounded-2xl border border-stone-100">
                                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-white border border-stone-200 text-stone-900 text-[10px] font-black flex items-center justify-center shadow-sm">
                                      {i + 1}
                                    </div>
                                    <p className="text-xs text-stone-600 leading-relaxed font-medium">{s}</p>
                                  </div>
                                ))}
                              </div>
                            )}

                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                              {step.requiredDocs && step.requiredDocs.length > 0 && (
                                <div className="flex-grow">
                                  <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-3">{t('documentationNeeded')}</p>
                                  <div className="flex flex-wrap gap-2">
                                    {step.requiredDocs.map((doc, i) => (
                                      <span key={i} className="px-3 py-1.5 bg-white border border-stone-200 text-stone-700 text-[10px] font-bold rounded-lg flex items-center gap-2 shadow-sm">
                                        <FileText className="w-3 h-3 text-stone-400" />
                                        {doc}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {step.officialLink && (
                                <div className="flex-shrink-0">
                                  <a
                                    href={step.officialLink}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-3 px-8 py-4 bg-stone-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-stone-800 transition-all shadow-xl shadow-stone-200"
                                  >
                                    {t('officialPortal')}
                                    <ExternalLink className="w-4 h-4" />
                                  </a>
                                </div>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <Guides />
        </div>
      </div>
    </div>
  );
}
