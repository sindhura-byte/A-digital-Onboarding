import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { VendorProfile } from '../types';
import { db } from '../firebase';
import { doc, setDoc } from 'firebase/firestore';
import { generateRoadmapSteps } from '../services/geminiService';
import { useLanguage } from '../contexts/LanguageContext';
import { Building2, MapPin, ShieldCheck, ShoppingBag, ArrowRight, ArrowLeft, Check, Loader2 } from 'lucide-react';

import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

interface OnboardingFormProps {
  userId: string;
  onComplete: (vendor: VendorProfile) => void;
}

export default function OnboardingForm({ userId, onComplete }: OnboardingFormProps) {
  const { t } = useLanguage();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    businessName: '',
    businessType: 'kirana' as VendorProfile['businessType'],
    location: '',
    sellOnline: false,
    hasGST: false,
    hasFSSAI: false,
    hasMSME: false,
    platforms: [] as string[]
  });

  const handleSubmit = async () => {
    setLoading(true);
    const vendorProfile: VendorProfile = {
      userId,
      ...formData,
      updatedAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, 'vendors', userId), vendorProfile);
      const roadmapSteps = await generateRoadmapSteps(vendorProfile, t('languageCode') || 'en');
      await setDoc(doc(db, 'roadmaps', userId), {
        userId,
        steps: roadmapSteps,
        language: t('languageCode') || 'en',
        updatedAt: new Date().toISOString()
      });
      onComplete(vendorProfile);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `vendors/${userId}`);
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => setStep(s => Math.min(s + 1, 4));
  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  const togglePlatform = (p: string) => {
    setFormData(prev => ({
      ...prev,
      platforms: prev.platforms.includes(p) 
        ? prev.platforms.filter(x => x !== p) 
        : [...prev.platforms, p]
    }));
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <Building2 className="w-6 h-6 text-emerald-600" />
              <h3 className="text-xl font-bold text-stone-900">{t('basicInfo')}</h3>
            </div>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">{t('businessName')}</label>
              <input
                type="text"
                required
                className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                placeholder="e.g. Ramesh Kirana Store"
                value={formData.businessName}
                onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">{t('businessType')}</label>
              <select
                className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                value={formData.businessType}
                onChange={(e) => setFormData({ ...formData, businessType: e.target.value as any })}
              >
                <option value="kirana">{t('businessTypeKirana')}</option>
                <option value="bakery">{t('businessTypeBakery')}</option>
                <option value="boutique">{t('businessTypeBoutique')}</option>
                <option value="other">{t('businessTypeOther')}</option>
              </select>
            </div>
          </motion.div>
        );
      case 2:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <MapPin className="w-6 h-6 text-emerald-600" />
              <h3 className="text-xl font-bold text-stone-900">{t('locationPresence')}</h3>
            </div>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">{t('location')}</label>
              <input
                type="text"
                required
                className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                placeholder="e.g. Hyderabad, Telangana"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              />
            </div>
            <div className="flex items-center gap-3 p-4 bg-stone-50 rounded-2xl border border-stone-100">
              <input
                type="checkbox"
                id="sellOnline"
                className="w-5 h-5 accent-emerald-600"
                checked={formData.sellOnline}
                onChange={(e) => setFormData({ ...formData, sellOnline: e.target.checked })}
              />
              <label htmlFor="sellOnline" className="text-sm font-medium text-stone-700">
                {t('sellOnline')}
              </label>
            </div>
          </motion.div>
        );
      case 3:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
              <h3 className="text-xl font-bold text-stone-900">{t('whichLicenses')}</h3>
            </div>
            <div className="space-y-3">
              {[
                { id: 'hasFSSAI', label: t('fssaiLicense') },
                { id: 'hasGST', label: t('gstReg') },
                { id: 'hasMSME', label: t('msmeReg') }
              ].map((item) => (
                <div 
                  key={item.id}
                  onClick={() => setFormData({ ...formData, [item.id]: !formData[item.id as keyof typeof formData] })}
                  className={`flex items-center justify-between p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                    formData[item.id as keyof typeof formData] ? 'border-emerald-500 bg-emerald-50' : 'border-stone-100 hover:border-stone-200'
                  }`}
                >
                  <span className="font-medium text-stone-700">{item.label}</span>
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    formData[item.id as keyof typeof formData] ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-stone-300'
                  }`}>
                    {formData[item.id as keyof typeof formData] && <Check className="w-4 h-4" />}
                  </div>
                </div>
              ))}
              <div 
                onClick={() => setFormData({ ...formData, hasFSSAI: false, hasGST: false, hasMSME: false })}
                className={`flex items-center justify-between p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  (!formData.hasFSSAI && !formData.hasGST && !formData.hasMSME) ? 'border-emerald-500 bg-emerald-50' : 'border-stone-100 hover:border-stone-200'
                }`}
              >
                <span className="font-medium text-stone-700">{t('noneOfThese')}</span>
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  (!formData.hasFSSAI && !formData.hasGST && !formData.hasMSME) ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-stone-300'
                }`}>
                  {(!formData.hasFSSAI && !formData.hasGST && !formData.hasMSME) && <Check className="w-4 h-4" />}
                </div>
              </div>
            </div>
          </motion.div>
        );
      case 4:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <ShoppingBag className="w-6 h-6 text-emerald-600" />
              <h3 className="text-xl font-bold text-stone-900">{t('whichPlatforms')}</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {['Swiggy', 'Zomato', 'Amazon', 'ONDC'].map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => togglePlatform(p)}
                  className={`p-4 rounded-2xl border-2 font-bold transition-all ${
                    formData.platforms.includes(p) ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-stone-100 text-stone-600 hover:border-stone-200'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-black text-stone-900 mb-2">{t('onboardingTitle')}</h2>
        <p className="text-stone-500 font-medium">{t('step')} {step} {t('of')} 4</p>
        
        {/* Progress Bar */}
        <div className="flex gap-2 mt-6 max-w-md mx-auto">
          {[1, 2, 3, 4].map((s) => (
            <div 
              key={s} 
              className={`h-2 flex-grow rounded-full transition-all duration-500 ${s <= step ? 'bg-emerald-500' : 'bg-stone-100'}`} 
            />
          ))}
        </div>
      </div>

      <div className="bg-white p-8 md:p-12 rounded-[2.5rem] shadow-xl shadow-stone-200/50 border border-stone-100 relative overflow-hidden">
        <AnimatePresence mode="wait">
          {renderStep()}
        </AnimatePresence>

        <div className="mt-12 pt-8 border-t border-stone-100 flex items-center justify-between">
          <button
            type="button"
            onClick={prevStep}
            disabled={step === 1}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              step === 1 ? 'opacity-0 pointer-events-none' : 'text-stone-500 hover:bg-stone-50'
            }`}
          >
            <ArrowLeft className="w-4 h-4" />
            {t('previous')}
          </button>

          {step < 4 ? (
            <button
              type="button"
              onClick={nextStep}
              className="flex items-center gap-2 px-8 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
            >
              {t('next')}
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={loading}
              className="flex items-center gap-2 px-8 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {t('generating')}
                </>
              ) : (
                t('generateRoadmap')
              )}
              {!loading && <ArrowRight className="w-4 h-4" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
