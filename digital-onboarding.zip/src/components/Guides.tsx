import { motion } from 'motion/react';
import { MessageSquare, Layout, FileText, Share2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Guides() {
  const { t } = useLanguage();

  const guides = [
    {
      title: t('stepWhatsApp'),
      description: t('whatsappGuideDesc'),
      icon: <MessageSquare className="w-6 h-6 text-green-500" />,
      link: 'https://www.whatsapp.com/business/'
    },
    {
      title: t('stepCatalog'),
      description: t('catalogGuideDesc'),
      icon: <Layout className="w-6 h-6 text-blue-500" />,
      link: '#'
    },
    {
      title: t('stepListing'),
      description: t('listingGuideDesc'),
      icon: <FileText className="w-6 h-6 text-orange-500" />,
      link: '#'
    }
  ];

  return (
    <div className="mt-12">
      <h3 className="text-xl font-bold text-stone-900 mb-6 flex items-center gap-2">
        <Share2 className="w-5 h-5 text-emerald-600" />
        {t('guides')}
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {guides.map((guide, i) => (
          <motion.div
            key={i}
            whileHover={{ y: -5 }}
            className="bg-white p-6 rounded-3xl border border-stone-100 shadow-sm hover:shadow-md transition-all"
          >
            <div className="w-12 h-12 rounded-2xl bg-stone-50 flex items-center justify-center mb-4">
              {guide.icon}
            </div>
            <h4 className="font-bold text-stone-900 mb-2">{guide.title}</h4>
            <p className="text-sm text-stone-500 mb-4">{guide.description}</p>
            <a 
              href={guide.link} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
            >
              {t('learnMore')}
              <Share2 className="w-3 h-3" />
            </a>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
