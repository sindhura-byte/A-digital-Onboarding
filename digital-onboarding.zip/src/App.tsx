import { useState, useEffect } from 'react';
import { auth, db, signInWithGoogle, logout } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { UserProfile, VendorProfile, OnboardingRoadmap } from './types';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import OnboardingForm from './components/OnboardingForm';
import Roadmap from './components/Roadmap';
import Chatbot from './components/Chatbot';
import Footer from './components/Footer';
import ErrorBoundary from './components/ErrorBoundary';
import AboutSection from './components/AboutSection';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from './contexts/LanguageContext';
import { handleFirestoreError, OperationType } from './utils/firestoreErrorHandler';

export default function App() {
  const { t } = useLanguage();
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [vendor, setVendor] = useState<VendorProfile | null>(null);
  const [roadmap, setRoadmap] = useState<OnboardingRoadmap | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let vendorUnsub: (() => void) | null = null;
    let roadmapUnsub: (() => void) | null = null;

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      // Clean up previous listeners if any
      if (vendorUnsub) {
        vendorUnsub();
        vendorUnsub = null;
      }
      if (roadmapUnsub) {
        roadmapUnsub();
        roadmapUnsub = null;
      }

      setUser(firebaseUser);
      if (firebaseUser) {
        // Sync user profile
        const userRef = doc(db, 'users', firebaseUser.uid);
        try {
          const userSnap = await getDoc(userRef);
          
          if (!userSnap.exists()) {
            const newProfile: UserProfile = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || '',
              photoURL: firebaseUser.photoURL || '',
              createdAt: new Date().toISOString(),
            };
            await setDoc(userRef, newProfile);
            setProfile(newProfile);
          } else {
            setProfile(userSnap.data() as UserProfile);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
        }

        // Listen for vendor profile
        vendorUnsub = onSnapshot(doc(db, 'vendors', firebaseUser.uid), (snap) => {
          if (snap.exists()) setVendor(snap.data() as VendorProfile);
        }, (error) => {
          // Only report error if we are still signed in
          if (auth.currentUser) {
            handleFirestoreError(error, OperationType.GET, `vendors/${firebaseUser.uid}`);
          }
        });

        // Listen for roadmap
        roadmapUnsub = onSnapshot(doc(db, 'roadmaps', firebaseUser.uid), (snap) => {
          if (snap.exists()) setRoadmap(snap.data() as OnboardingRoadmap);
        }, (error) => {
          // Only report error if we are still signed in
          if (auth.currentUser) {
            handleFirestoreError(error, OperationType.GET, `roadmaps/${firebaseUser.uid}`);
          }
        });

        setLoading(false);
      } else {
        setProfile(null);
        setVendor(null);
        setRoadmap(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribe();
      if (vendorUnsub) vendorUnsub();
      if (roadmapUnsub) roadmapUnsub();
    };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-stone-50">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-stone-50 text-stone-900 font-sans selection:bg-emerald-100">
        <Navbar user={user} onLogin={signInWithGoogle} onLogout={logout} />
        
        <main>
          <AnimatePresence mode="wait">
            {!user ? (
              <div key="hero">
                <Hero onGetStarted={signInWithGoogle} />
                <AboutSection />
              </div>
            ) : !vendor ? (
              <OnboardingForm key="onboarding" userId={user.uid} onComplete={setVendor} />
            ) : (
              <Roadmap key="roadmap" vendor={vendor} roadmap={roadmap} />
            )}
          </AnimatePresence>
        </main>

        <Chatbot />
        <Footer />
      </div>
    </ErrorBoundary>
  );
}
