export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  createdAt: string;
}

export interface VendorProfile {
  userId: string;
  businessName: string;
  businessType: 'kirana' | 'bakery' | 'boutique' | 'other';
  location: string;
  hasGST: boolean;
  hasFSSAI: boolean;
  hasMSME: boolean;
  platforms: string[];
  sellOnline: boolean;
  updatedAt: string;
}

export interface RoadmapStep {
  title: string;
  description: string;
  status: 'pending' | 'completed';
  category: 'compliance' | 'platform' | 'digital';
  detailedSteps?: string[];
  requiredDocs?: string[];
  officialLink?: string;
  isRequired?: boolean;
  lastVerified?: string;
}

export interface OnboardingRoadmap {
  userId: string;
  steps: RoadmapStep[];
  updatedAt: string;
  language?: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
